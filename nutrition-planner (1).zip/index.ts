import "jsr:@supabase/functions-js/edge-runtime.d.ts";
// ---------- CORS ----------
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
  "Access-Control-Allow-Headers": "authorization,content-type"
};
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      ...CORS
    }
  });
}
// ---------- YOUR SYSTEM PROMPT ----------
const SYSTEM_PROMPT = `
You are a clinical-grade nutrition planning assistant.
Your mission: generate safe, realistic, evidence-based diet plans tailored to every user, always grounded first in DB_CONTEXT (curated articles we provide).

1. Input Normalization
Detect the language of the user's inputs (labs, medications, preferences).
Internally translate & normalize all inputs into English and canonical keys for reasoning and for matching with DB_CONTEXT.
Preserve numeric values and units; if unit conversion is needed, show both original and converted.
Inputs include:
Demographics: age, sex.
Anthropometrics: height_cm, weight_kg, and compute BMI.
Lifestyle: activity_level (sedentary / light / moderate / high / athlete), goal (fat_loss / muscle_gain / maintenance).
Plan duration: duration_days or duration_weeks.
Diet constraints: allergies, intolerances, diet_style (e.g., mediterranean, keto, vegetarian), religious_rules, avoid_ingredients, cuisines_like, cuisines_avoid, budget_level, cooking_time_minutes, equipment, meals_per_day, fasting_window.
Medical: medical_conditions (map to ICD-style names if possible).
Medications: normalize to generic names (note common dose units).
Labs: normalize to canonical markers and standard units when possible.
Do not drop or ignore any user constraint.
Record notes about inconsistencies (e.g., extreme BMI, nonsensical units) under warnings.

2. Evidence Use (DB first, Web search if needed)
Always rely FIRST on DB_CONTEXT (excerpts from our curated database). Cite each recommendation from it as:
{ "source_type":"db", "title":"...", "url": null }
If DB_CONTEXT lacks coverage for a needed point, use the web_search function to find information from trusted medical domains (WHO, NIH/NCBI, CDC, EMA, Mayo Clinic, WebMD). Cite results as:
{ "source_type":"web", "url":"...", "date":"YYYY-MM-DD" }
Never invent sources. Always search for missing information when database coverage is insufficient.

3. Safety & Medical Guardrails
No diagnosis or treatment. Nutrition advice only.
Screen for lab red flags: high LDL, low hemoglobin, poor vitamin D, low B12, high fasting glucose/HbA1c, CKD (eGFR), hypertriglyceridemia, hypertension.
Respect condition–medication–nutrient interactions:
Use DB_CONTEXT first and established medical knowledge.
List foods to avoid with common medications (e.g., statins ↔ grapefruit, warfarin ↔ vitamin K, metformin ↔ B12, MAOIs ↔ aged cheeses, ACE inhibitors ↔ potassium).
Add concise warnings for each flagged risk.

4. Diet Construction
Estimate TDEE and adjust calories by goal and duration.
Set protein (g/kg) appropriate to goal and conditions.
Respect all constraints: allergies, intolerances, religious rules, avoid_ingredients, cuisines_avoid, budget, cooking_time, equipment, meals_per_day, fasting_window.
Never include foods the user explicitly avoids.

5. Plan Duration & Smart Scaling
For short periods (1-14 days): Create detailed daily meal plans with full ingredients, portions, and instructions.
For medium periods (15-60 days): Create weekly templates with 7 detailed days that can be repeated/rotated, plus substitution guidance.
For long periods (61+ days): Create monthly templates with 4 weekly patterns, seasonal adjustments, and variety guidelines.
Each plan should include specific calories, protein targets, and meal timing regardless of duration.

6. Output Language
For reasoning, always use the normalized English inputs and DB_CONTEXT.
For the final plan output:
If uiLanguage is provided, output all food names, meal descriptions, warnings, and rationale in that language.
If missing, default to English.

7. Output Format
Respond only with valid JSON matching the schema.
Must include:
 - normalized_inputs (all inputs normalized into English, plus BMI).
 - plan with daily calories, protein_g, and meals per day (with meal name, items[], kcal, protein_g).
 - warnings (short list of cautions).
 - citations (db/web as above).
No text outside JSON.
`;
function buildDbContextString(dbItems = [], maxItems = 10, maxCharsPerExcerpt = 900) {
  const trimmed = dbItems.slice(0, maxItems).map((it)=>({
      title: it.title,
      url: it.url ?? null,
      excerpt: (it.excerpt ?? "").slice(0, maxCharsPerExcerpt)
    }));
  return JSON.stringify(trimmed, null, 2);
}
Deno.serve(async (req)=>{
  if (req.method === "OPTIONS") return new Response(null, {
    headers: CORS
  });
  try {
    const key = Deno.env.get("OPENAI_API_KEY");
    if (!key) return json({
      error: "Missing OPENAI_API_KEY"
    }, 500);
    const body = await req.json().catch(()=>({}));
    // Accept two modes:
    // A) { messages: [...] } -> send your own messages (we'll add system + DB_CONTEXT)
    // B) { fields... , db_context:[...] } -> pass structured inputs and DB_CONTEXT
    const dbContext = Array.isArray(body?.db_context) ? body.db_context : [];
    let messages = [];
    if (Array.isArray(body?.messages)) {
      messages = [
        {
          role: "system",
          content: SYSTEM_PROMPT
        },
        {
          role: "system",
          content: `DB_CONTEXT (JSON array of curated sources):\n${buildDbContextString(dbContext)}`
        },
        ...body.messages
      ];
    } else {
      // Build user prompt from fields to cover all inputs
      const { uiLanguage = "en", age, sex, height_cm, weight_kg, activity_level, goal, duration_days, duration_weeks, allergies = [], intolerances = [], diet_style, religious_rules, avoid_ingredients = [], cuisines_like = [], cuisines_avoid = [], budget_level, cooking_time_minutes, equipment = [], meals_per_day, fasting_window, medical_conditions = [], medications = [], labs = {}, note = "" } = body || {};
      const userPrompt = {
        uiLanguage,
        age,
        sex,
        height_cm,
        weight_kg,
        activity_level,
        goal,
        duration_days,
        duration_weeks,
        allergies,
        intolerances,
        diet_style,
        religious_rules,
        avoid_ingredients,
        cuisines_like,
        cuisines_avoid,
        budget_level,
        cooking_time_minutes,
        equipment,
        meals_per_day,
        fasting_window,
        medical_conditions,
        medications,
        labs,
        note
      };
      messages = [
        {
          role: "system",
          content: SYSTEM_PROMPT
        },
        {
          role: "system",
          content: `DB_CONTEXT (JSON array of curated sources):\n${buildDbContextString(dbContext)}`
        },
        {
          role: "user",
          content: JSON.stringify(userPrompt)
        }
      ];
    }
    console.log('Calling OpenAI for nutrition planning with updated deployment...');
    const r = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "gpt-4.1-2025-04-14",
        messages,
        temperature: 0.3,
        max_tokens: 8000,
        response_format: {
          type: "json_object"
        },
        tools: [
          {
            type: "function",
            function: {
              name: "web_search",
              description: "Search the web for medical/nutrition information from trusted sources",
              parameters: {
                type: "object",
                properties: {
                  query: {
                    type: "string",
                    description: "Search query for medical/nutrition information"
                  }
                },
                required: [
                  "query"
                ]
              }
            }
          }
        ],
        tool_choice: "auto"
      })
    });
    const data = await r.json();
    if (!r.ok) {
      console.error('OpenAI API error:', data);
      return json({
        error: data.error?.message || 'OpenAI API error'
      }, r.status);
    }
    // Handle function calls (web search)
    if (data.choices?.[0]?.message?.tool_calls) {
      console.log('GPT requested web search');
      const toolCalls = data.choices[0].message.tool_calls;
      for (const toolCall of toolCalls){
        if (toolCall.function.name === 'web_search') {
          const searchQuery = JSON.parse(toolCall.function.arguments).query;
          console.log('Searching for:', searchQuery);
          // Simple web search using a search API (you can use any search service)
          try {
            const searchResponse = await fetch(`https://api.tavily.com/search`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${Deno.env.get('TAVILY_API_KEY') || 'demo'}`
              },
              body: JSON.stringify({
                query: searchQuery + " site:nih.gov OR site:who.int OR site:mayoclinic.org OR site:webmd.com",
                max_results: 3
              })
            });
            const searchData = await searchResponse.json();
            console.log('Search results found');
            // Continue conversation with search results
            const newMessages = [
              ...messages,
              data.choices[0].message,
              {
                role: "tool",
                tool_call_id: toolCall.id,
                content: JSON.stringify(searchData.results || [])
              }
            ];
            const followUpResponse = await fetch("https://api.openai.com/v1/chat/completions", {
              method: "POST",
              headers: {
                "Authorization": `Bearer ${key}`,
                "Content-Type": "application/json"
              },
              body: JSON.stringify({
                model: "gpt-4.1-2025-04-14",
                messages: newMessages,
                temperature: 0.3,
                max_tokens: 8000,
                response_format: {
                  type: "json_object"
                }
              })
            });
            const followUpData = await followUpResponse.json();
            console.log('Nutrition plan generated with web search');
            return json(followUpData, followUpResponse.status);
          } catch (searchError) {
            console.error('Web search failed:', searchError);
          // Continue without web search
          }
        }
      }
    }
    console.log('Nutrition plan generated successfully');
    return json(data, r.status);
  } catch (e) {
    console.error("EDGE ERROR:", e);
    return json({
      error: String(e)
    }, 500);
  }
});
